//---------------------------------------------------------------------------------
// Gestione DIVIDIPALLINE 12/2020   by Fabio Becherini  <fabio.becherini@gmail.com>
//---------------------------------------------------------------------------------
#include <EEPROM.h>
#include <SPI.h>
#include <Wire.h>
#include "Src\Adafruit_GFX_Library\Adafruit_GFX.h"
#include "Src\My_SSD1306\Adafruit_SSD1306.h"
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);
const byte S0=12, S1=11, S2=10, S3=9;
const byte FOUT=8, PISTONE=5, TONO=13, SHAKER=7;
const byte STEP_ZERO=6, STEP_A=A0, STEP_B=A1, STEP_C=A2, STEP_D=A3;
const byte FREE1=A6, FREE2=A7;
const byte HALL_CLK=4, HALL_LD=3, HALL_SIN=2;
const int RITARDO_STEP=2600, TEMPO_SHAKER=6000;
int Rval, Bval, Gval, srHall;
byte RGBval, nFase, posScivolo;
int colore[15], posto[5], cassetto[5];
long distanza[5], timeoutShaker;
int conta[5]={0,0,0,0,0};
int posCurs[5]={0, 0, 34, 68, 102};
int nota[5]={0, 880, 1109, 1319, 1760};
boolean letturaOk, cassettiPresenti;

//----------------------------------------------------------
void setup()
{ 
  pinMode(TONO, OUTPUT);
  pinMode(S0, OUTPUT);
  pinMode(S1, OUTPUT);
  pinMode(S2, OUTPUT);
  pinMode(S3, OUTPUT);
  pinMode(STEP_A, OUTPUT);
  pinMode(STEP_B, OUTPUT);
  pinMode(STEP_C, OUTPUT);
  pinMode(STEP_D, OUTPUT);
  pinMode(SHAKER, OUTPUT);
  pinMode(HALL_LD, OUTPUT);
  pinMode(HALL_CLK, OUTPUT);
  pinMode(PISTONE, OUTPUT);
  pinMode(FOUT, INPUT_PULLUP);
  pinMode(HALL_SIN, INPUT_PULLUP);
  pinMode(STEP_ZERO, INPUT_PULLUP);
  digitalWrite(S0, 1);
  digitalWrite(S1, 0);
  digitalWrite(S2, 1);
  digitalWrite(S3, 0);
  digitalWrite(STEP_A, 1);
  digitalWrite(STEP_B, 0);
  digitalWrite(STEP_C, 0);
  digitalWrite(STEP_D, 0);
  nFase=0;
  digitalWrite(SHAKER, 0);
  digitalWrite(PISTONE, 0);
  digitalWrite(HALL_LD, 1);
  digitalWrite(HALL_CLK, 0);
  Serial.begin(115200);
  Serial.println();

  leggiCassetti();
  cercaZeroSTEP();
  if (analogRead(FREE2)<100)
  { if (cassettiPresenti) {taraTCS3200(); for(byte i=1; i<5; i++) conta[i]=1;}
    else arrestoPerErrore(3);
  }
  leggiEEPROM();
  timeoutShaker=millis();

  delay(500);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(WHITE);
  display.display(4);
  visualizzaContatori();  

  if (analogRead(FREE1)<100) testCassetti();
}
//----------------------------------------------------------
void loop()
{
  Serial.println("Aspetta pallina...");
  do
  { RGBval=leggiTCS3200();  
    visualizzaContatori();
    if (millis()>timeoutShaker) digitalWrite(SHAKER, 0);
  } while (RGBval==0);
  
  Serial.println();
  leggiCassetti();

  delay(100);
  digitalWrite(SHAKER, 1);
  timeoutShaker=millis()+TEMPO_SHAKER;
  RGBval=leggiTCS3200();  
  Serial.print("Pallina colore... "); Serial.println(RGBval);
  if (RGBval>0)
  { if (cassettiPresenti)
    { spostaScivolo(cassetto[RGBval]);
      espelliPallina();
      if (conta[RGBval]<99) conta[RGBval]++;
      else conta[RGBval]=0;
      tone(TONO, nota[RGBval], 200);
    }
  }
}
//----------------------------------------------------------
void visualizzaContatori(void)
{ display.clearDisplay(); //Pulisce buffer
  display.setCursor(posCurs[cassetto[1]],0); if (conta[1]<10) display.print(" ");  display.print(conta[1]);
  display.setCursor(posCurs[cassetto[2]],0); if (conta[2]<10) display.print(" ");  display.print(conta[2]);
  display.setCursor(posCurs[cassetto[3]],0); if (conta[3]<10) display.print(" ");  display.print(conta[3]);
  display.setCursor(posCurs[cassetto[4]],0); if (conta[4]<10) display.print(" ");  display.print(conta[4]);
  display.display(2); //Invia il buffer al display
}  
//----------------------------------------------------------
byte leggiTCS3200(void)
{ //restituisce un indice con valore:  0=niente  1 2 3 4=colore
  digitalWrite(S2, 0); digitalWrite(S3, 0); //filtro rosso
  Rval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 0); digitalWrite(S3, 1); //filtro blu
  Bval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 1); //filtro verde
  Gval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 0); //senza filtro
//  Serial.print(Rval); Serial.print("\t");    Serial.print(Bval); Serial.print("\t");    Serial.print(Gval); Serial.print("\t");Serial.print("\t");
  for (byte i=0; i<=4; i++)
  { distanza[i] = (long)(Rval-colore[i*3])*(Rval-colore[i*3]) + (long)(Gval-colore[i*3+1])*(Gval-colore[i*3+1]) + (long)(Bval-colore[i*3+2])*(Bval-colore[i*3+2]);
//    Serial.print(distanza[i]); Serial.print("\t"); 
  }
  long minVal=distanza[0];
  byte RGBval=0;
  for (byte i=1; i<=4; i++)
  { if (distanza[i]<minVal)
    { minVal=distanza[i];
      RGBval=i;
    }
  }
//  Serial.println(RGBval);
  return RGBval;
}
//----------------------------------------------------------
void spostaScivolo(byte nuovaPosizione)
{
  int deltaPos = (int) nuovaPosizione-posScivolo;
  Serial.print("Sposta scivolo in..."); Serial.println(nuovaPosizione);
  if (deltaPos>0) 
  { StepMotorOut(25*deltaPos,1); 
  }
  else if (deltaPos<0) 
  { deltaPos=-deltaPos;
    StepMotorOut(25*deltaPos,0); 
  }
  //delay(100);    
  posScivolo=nuovaPosizione;
}
//----------------------------------------------------------
void cercaZeroSTEP()
{
  Serial.print("Cerca Fine Corsa...");
  while (digitalRead(STEP_ZERO)==0)  {StepMotorOut(1,1); delay(8);}
  StepMotorOut(11,0);
  posScivolo=4;
  Serial.println("Trovato");
}
//----------------------------------------------------------
void StepMotorOut(int nPassi, boolean direzione)
{
  for (int passo=1; passo<=nPassi; passo++)
  { if (direzione==0)
    { if      (nFase==0)  {digitalWrite(STEP_A, 0); digitalWrite(STEP_B, 1); nFase=1;}
      else if (nFase==1)  {digitalWrite(STEP_B, 0); digitalWrite(STEP_C, 1); nFase=2;}
      else if (nFase==2)  {digitalWrite(STEP_C, 0); digitalWrite(STEP_D, 1); nFase=3;}
      else if (nFase==3)  {digitalWrite(STEP_D, 0); digitalWrite(STEP_A, 1); nFase=0;}
    }
    else
    { if      (nFase==0)  {digitalWrite(STEP_A, 0); digitalWrite(STEP_D, 1); nFase=3;}
      else if (nFase==3)  {digitalWrite(STEP_D, 0); digitalWrite(STEP_C, 1); nFase=2;}
      else if (nFase==2)  {digitalWrite(STEP_C, 0); digitalWrite(STEP_B, 1); nFase=1;}
      else if (nFase==1)  {digitalWrite(STEP_B, 0); digitalWrite(STEP_A, 1); nFase=0;}
    }
    delayMicroseconds(RITARDO_STEP);
  }
}
//----------------------------------------------------------
void leggiCassetti(void)
{
  cassettiPresenti = false; 
  for (byte i=0; i<5; i++) {posto[i]=0; cassetto[i]=0;}
  digitalWrite(HALL_LD, 0); digitalWrite(HALL_LD, 1);  //Latch
  digitalWrite(HALL_CLK, 1); digitalWrite(HALL_CLK, 0);  //Clock
  srHall = 0;
  digitalWrite(HALL_LD, 0); digitalWrite(HALL_LD, 1);  //Latch
  for (byte i=0; i<16; i++)
  { srHall = srHall<<1;
    srHall = srHall + digitalRead(HALL_SIN);
    digitalWrite(HALL_CLK, 1); digitalWrite(HALL_CLK, 0);  //Clock
  }
  Serial.print("Shift Register sensori Hall... ");   Serial.println(srHall, BIN); 
  letturaOk = ((srHall & 0x2222)==0x2020);
  if (letturaOk)
  { cassettiPresenti = ((srHall & 0x4444)==0); 
    if (cassettiPresenti)
    { posto[1] = ((srHall & 0x0008)==0)*2 + ((srHall & 0x0001)==0) +1; 
      posto[2] = ((srHall & 0x0080)==0)*2 + ((srHall & 0x0010)==0) +1; 
      posto[3] = ((srHall & 0x0800)==0)*2 + ((srHall & 0x0100)==0) +1; 
      posto[4] = ((srHall & 0x8000)==0)*2 + ((srHall & 0x1000)==0) +1; 
      for (byte i=1; i<5; i++) cassetto[posto[i]] = i;
    }
  }
  else
  { arrestoPerErrore(5);
  }  
  //Serial.print(letturaOk); Serial.print(" "); Serial.print(cassettiPresenti); Serial.print("\t");  
  Serial.print("Posizione... "); for (byte i=1; i<5; i++) {Serial.print(posto[i]); Serial.print(" ");} Serial.print("\t"); 
  Serial.print("Cassetto... "); for (byte i=1; i<5; i++) {Serial.print(cassetto[i]); Serial.print(" ");} Serial.print("\t"); 
  //Serial.print(srHall, HEX);
  Serial.println();
}
//----------------------------------------------------------
void taraTCS3200(void)
{
  int Rsum,Gsum,Bsum;
  Serial.println("Taratura TCS3200...");
  for (byte col=0; col<=4; col++)
  { delay(500);
    Serial.print("Colore  "); Serial.println(col);
    Rsum=0; Gsum=0; Bsum=0;
    for(byte i=0; i<32; i++)
    { byte val=leggiTCS3200();
      Rsum=Rsum+Rval;
      Gsum=Gsum+Gval;
      Bsum=Bsum+Bval;
      delay(10);
    }
    Rsum = Rsum>>5; Gsum = Gsum>>5; Bsum = Bsum>>5;
    Serial.print("Risultato...");Serial.print(Rsum); Serial.print(" ");Serial.print(Gsum);Serial.print(" ");Serial.println(Bsum);   
    if (col<4)
    { spostaScivolo(col+1);
      espelliPallina();
      colore[(posto[col+1]*3)+0] = Rsum; colore[(posto[col+1]*3)+1] = Gsum; colore[(posto[col+1]*3)+2] = Bsum;
    }
    else
    { colore[0] = Rsum; colore[1] = Gsum; colore[2] = Bsum;
    }
  }
  for (byte i=0; i<15; i++)
  { Serial.print(colore[i]); Serial.print(" "); if((i % 3)==2) Serial.print("\t");
  }
  Serial.println(); Serial.println("Salva dati su Eprom...");
  byte addr=0;  //Salva su EEPROM
  for (byte i=0; i<15; i++)
  { EEPROM.write(addr, colore[i]/256); addr++; EEPROM.write(addr, colore[i]%256); addr++;
  }
  Serial.println();
  leggiEEPROM();
}
//----------------------------------------------------------
void espelliPallina()
{ 
  Serial.println("Espelle pallina");
  digitalWrite(PISTONE, 1);
  delay(60);
  digitalWrite(PISTONE, 0);
}  
//----------------------------------------------------------
void leggiEEPROM()
{
  Serial.println("Legge Eprom...");
  for (byte k=0; k<15; k++)
  { colore[k] = EEPROM.read(k*2 + 0)*256 + EEPROM.read(k*2 + 1);
    Serial.print(colore[k]); Serial.print(" ");
    if ((k % 3)==2)Serial.print("\t");
  }
  Serial.println();
}
//----------------------------------------------------------
void arrestoPerErrore(byte numBeep)
{
  digitalWrite(STEP_A, 0);
  digitalWrite(STEP_B, 0);
  digitalWrite(STEP_C, 0);
  digitalWrite(STEP_D, 0);
  digitalWrite(SHAKER, 0);
  digitalWrite(PISTONE, 0);
  for (byte i=0; i<numBeep; i++)
  { tone(TONO, 1000, 200);
    delay(1000);
  }
  while (true);
}
//----------------------------------------------------------
void testCassetti(void)
{ display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(1);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.display(4); //Invia il buffer da visualizzare al display

  while(true)
  { leggiCassetti();
    srHall = ~srHall;
    
    display.clearDisplay();  //Pulisce il buffer da inviare al display
    display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
    if (srHall & 0x0008) display.print("O"); else display.print(" ");
    if (srHall & 0x0004) display.print("-"); else display.print(" ");
    if (srHall & 0x0001) display.print("O"); else display.print(" ");
    display.print("   ");
    if (srHall & 0x0080) display.print("O"); else display.print(" ");
    if (srHall & 0x0040) display.print("-"); else display.print(" ");
    if (srHall & 0x0010) display.print("O"); else display.print(" ");
    display.print("   ");
    if (srHall & 0x0800) display.print("O"); else display.print(" ");
    if (srHall & 0x0400) display.print("-"); else display.print(" ");
    if (srHall & 0x0100) display.print("O"); else display.print(" ");
    display.print("   ");
    if (srHall & 0x8000) display.print("O"); else display.print(" ");
    if (srHall & 0x4000) display.print("-"); else display.print(" ");
    if (srHall & 0x1000) display.print("O"); else display.print(" ");
    display.setCursor(7,12); display.print(posto[1]);
    display.print("     ");  display.print(posto[2]);
    display.print("     ");  display.print(posto[3]);
    display.print("     ");  display.print(posto[4]);
    display.setCursor(7,24); display.print(cassetto[1]);
    display.print("     ");  display.print(cassetto[2]);
    display.print("     ");  display.print(cassetto[3]);
    display.print("     ");  display.print(cassetto[4]);
    display.display(4); //Invia il buffer da visualizzare al display
  }
}
//----------------------------------------------------------
  
