// Test SENSORE RGB TCS3200    10/2020

#include <EEPROM.h>
byte S0=12, S1=11, S2=10, S3=9, FOUT=8, PISTONE=5, LEDR=13;
int Rval, Bval, Gval;
int color[15];
long distanza[5];
//----------------------------------------------------------
void setup()
{
  pinMode(LEDR, OUTPUT);
  pinMode(S0, OUTPUT);
  pinMode(S1, OUTPUT);
  pinMode(S2, OUTPUT);
  pinMode(S3, OUTPUT);
  pinMode(PISTONE, OUTPUT);
  pinMode(FOUT, INPUT_PULLUP);
  digitalWrite(S0, 1);
  digitalWrite(S1, 0);
  digitalWrite(PISTONE, 0);
  Serial.begin(115200);
  Serial.println();
//  taraTCS3200();
//  salvaEeprom();
  leggiEeprom();
}
//----------------------------------------------------------
void loop()
{
  byte RGBval=leggiTCS3200();  
  if      (RGBval==0) Serial.println("111111");
  else if (RGBval==1) Serial.println("222222");
  else if (RGBval==2) Serial.println("333333");
  else if (RGBval==3) Serial.println("444444");
  else if (RGBval==4) Serial.println("555555");
  delay(2);
}

//----------------------------------------------------------
byte leggiTCS3200(void)
{ //restituisce un indice con valore:  0=niente  1=bianco  2=giallo  3=blu  4=rosso
  digitalWrite(S2, 0); digitalWrite(S3, 0); //filtro rosso
  Rval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 0); digitalWrite(S3, 1); //filtro blu
  Bval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 1); //filtro verde
  Gval = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 0); //senza filtro
//  Serial.print(Rval); Serial.print("\t");    Serial.print(Bval); Serial.print("\t");    Serial.print(Gval); Serial.print("\t");Serial.print("\t");
  for (byte i=0; i<=4; i++)
  { distanza[i] = (long)(Rval-color[i*3])*(Rval-color[i*3]) + (long)(Bval-color[i*3+1])*(Bval-color[i*3+1]) + (long)(Gval-color[i*3+2])*(Gval-color[i*3+2]);
    Serial.print(distanza[i]); Serial.print("\t"); 
  }
  long minVal=distanza[0];
  byte RGBval=0;
  for (byte i=1; i<=4; i++)
  { if (distanza[i]<minVal)
    { minVal=distanza[i];
      RGBval=i;
    }
  }
  return RGBval;
}
//----------------------------------------------------------
void taraTCS3200(void)
{
  int Rsum,Gsum,Bsum;
  for (byte col=0; col<=4; col++)
  { delay(500);
    Rsum=0; Gsum=0; Bsum=0;
    for(byte i=0; i<32; i++)
    { byte val=leggiTCS3200();
      Rsum=Rsum+Rval;
      Gsum=Gsum+Gval;
      Bsum=Bsum+Bval;
      delay(1);
    }
    espelliPallina();
    color[(col*3)+0] = Rsum>>5;
    color[(col*3)+1] = Bsum>>5;
    color[(col*3)+2] = Gsum>>5;
//    Serial.print(color[(col*3)+0]); Serial.print("\t"); Serial.print(color[(col*3)+1]); Serial.print("\t"); Serial.print(color[(col*3)+2]); Serial.println("\t"); 
  }
}
//----------------------------------------------------------
void espelliPallina()
{ digitalWrite(PISTONE, 1);
  delay(60);
  digitalWrite(PISTONE, 0);
}  
//----------------------------------------------------------
void leggiEeprom()
{
  for (byte k=0; k<15; k++)
  { color[k] = EEPROM.read(k*2 + 0)*256 + EEPROM.read(k*2 + 1);
    Serial.print(color[k]); Serial.print("\t");
  }
  Serial.println();
}
//----------------------------------------------------------
void salvaEeprom()
{
  for (byte i=0; i<15; i++)
  { EEPROM.write(i*2 + 0, color[i]/256);
    EEPROM.write(i*2 + 1, color[i]%256);
  }
}
//----------------------------------------------------------
