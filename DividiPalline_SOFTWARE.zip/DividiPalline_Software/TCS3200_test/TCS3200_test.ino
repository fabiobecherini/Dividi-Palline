// Test SENSORE RGB TCS3200    10/2020

byte S0=12, S1=11, S2=10, S3=9, FOUT=8;
byte LEDR=13;
int redValue, blueValue, greenValue;
//.................   niente     bianco     giallo        blu           rosso
//const int color[] = {10,22,23,   4,4,4,     4,8,8,        9,7,7,     4,13,13};
const int color[] = {110,215,215,  32,32,32,   32,75,75,   94,59,59,    35,128,128};

long distanza[5];
byte contaColor;
//----------------------------------------------------------
void setup()
{
  pinMode(S0, OUTPUT);
  pinMode(S1, OUTPUT);
  pinMode(S2, OUTPUT);
  pinMode(S3, OUTPUT);
  pinMode(LEDR, OUTPUT);
  pinMode(FOUT, INPUT_PULLUP);
  digitalWrite(S0, 1);
  digitalWrite(S1, 0);
  Serial.begin(115200);
}
//----------------------------------------------------------
void loop()
{
  byte index=leggiTCS3200();  
  if (index==0)      Serial.println("NIENTE");
  else if (index==1) Serial.println("BIANCO");
  else if (index==2) Serial.println("GIALLO");
  else if (index==3) Serial.println("BLU");
  else if (index==4) Serial.println("ROSSO");
  delay(2);
}

//----------------------------------------------------------
byte leggiTCS3200(void)
{ //restituisce un indice con valore:  0=niente  1=bianco  2=giallo  3=blu  4=rosso
  digitalWrite(S2, 0); digitalWrite(S3, 0); //filtro rosso
  redValue = pulseIn(FOUT, 1); 
  digitalWrite(S2, 0); digitalWrite(S3, 1); //filtro blu
  blueValue = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 1); //filtro verde
  greenValue = pulseIn(FOUT, 1); 
  digitalWrite(S2, 1); digitalWrite(S3, 0); //senza filtro
  Serial.print(redValue); Serial.print("\t");    Serial.print(blueValue); Serial.print("\t");    Serial.print(greenValue); Serial.print("\t");Serial.print("\t");
  for (byte i=0; i<=4; i++)
  { distanza[i] = (long)(redValue-color[i*3])*(redValue-color[i*3]) + (long)(blueValue-color[i*3+1])*(blueValue-color[i*3+1]) + (long)(greenValue-color[i*3+2])*(greenValue-color[i*3+2]);
    Serial.print(distanza[i]); Serial.print("\t"); 
  }
  long minVal=distanza[0];
  byte index=0;
  for (byte i=1; i<=4; i++)
  { if (distanza[i]<minVal)
    { minVal=distanza[i];
      index=i;
    }
  }
  return index;
}
