//-------------------------------------------------------------------------
// Esempio di TERMOMETRO con DS18B20 visualizzato su OLED I2C    fb.02/2021
//-------------------------------------------------------------------------
#include <SPI.h>                    //Librerie per la gestione OLED
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);

#include <OneWire.h>                //Librerie per la gestione DS18B20
#include <DallasTemperature.h>
#define DS18B20_Pin  2
OneWire ds18b20(DS18B20_Pin);
DallasTemperature sensors(&ds18b20);
 
//-------------------------------------------------------------------------
void setup(void)
{
  Serial.begin(115200);                       //init Monitor seriale
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //init OLED
  display.clearDisplay();
  display.setTextSize(3);
  display.setTextColor(WHITE);
  //display.display();

  sensors.begin();                            //init DS18B20
}
//-------------------------------------------------------------------------
void loop(void)
{
  sensors.requestTemperatures();
  float temperature = sensors.getTempCByIndex(0);
  
  Serial.println(temperature);
  
  display.clearDisplay();
  display.setCursor(30,16);
  display.print(temperature, 1);
  display.display();
  
  delay(500);
}
//-------------------------------------------------------------------------
