//Test MOTORE passo-passi BIPOLARE   10/2020

byte stepA1=2, stepA2=3, stepB1=4, stepB2=5;
byte nFase=0;
byte LEDR=13;
//byte fase[]={0b0101, 0b0110, 0b1010, 0b1001};
//byte fase[]={0b1000, 0b0010, 0b0100, 0b0001};
byte fase[]={0b1000, 0b1010, 0b0010, 0b0110, 0b0100, 0b0101, 0b0001, 0b1001};
void setup()
{
  pinMode(stepA1, OUTPUT);
  pinMode(stepA2, OUTPUT);
  pinMode(stepB1, OUTPUT);
  pinMode(stepB2, OUTPUT);
  pinMode(LEDR, OUTPUT);
  nFase=0;
  StepMotorOut(1,0,1000);
}

void loop()
{
  StepMotorOut(20,0,20);
//  delay(1000);
  StepMotorOut(20,1,10);
//  delay(1000);
}
void StepMotorOut(int nPassi, boolean direzione, int mSritardo)
{
  for (int passo=1; passo<nPassi; passo++)
  { if (direzione==0)
//    { if (nFase<3) nFase++; else nFase=0;
//    }
//    else
//    { if (nFase>0) nFase--; else nFase=3;
//    }
    { if (nFase<7) nFase++; else nFase=0;
    }
    else
    { if (nFase>0) nFase--; else nFase=7;
    }
    digitalWrite(stepA1, fase[nFase]&1);
    digitalWrite(stepA2, fase[nFase]&2);
    digitalWrite(stepB1, fase[nFase]&4);
    digitalWrite(stepB2, fase[nFase]&8);
    delay(mSritardo);
  }
}

