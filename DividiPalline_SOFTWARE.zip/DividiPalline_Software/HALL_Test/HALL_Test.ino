#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);
const byte HALL_CLK=4, HALL_LD=3, HALL_SIN=2;
int colore[15], posto[5], cassetto[5];
int srHall;
//--------------------------------------------------
void setup()   {    
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //Impostare l'indirizzo i2c annotato in precedenza
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(1);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.display(4); //Invia il buffer da visualizzare al display

  pinMode(HALL_LD, OUTPUT);
  pinMode(HALL_CLK, OUTPUT);
  pinMode(HALL_SIN, INPUT_PULLUP);
  digitalWrite(HALL_LD, 1);
  digitalWrite(HALL_CLK, 0);
}
//--------------------------------------------------
void loop()
{
  leggiCassetti();
  srHall = ~srHall;
  
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  if (srHall & 0x0008) display.print("O"); else display.print(" ");
  if (srHall & 0x0004) display.print("."); else display.print(" ");
  if (srHall & 0x0001) display.print("O"); else display.print(" ");
  display.print("   ");
  if (srHall & 0x0080) display.print("O"); else display.print(" ");
  if (srHall & 0x0040) display.print("."); else display.print(" ");
  if (srHall & 0x0010) display.print("O"); else display.print(" ");
  display.print("   ");
  if (srHall & 0x0800) display.print("O"); else display.print(" ");
  if (srHall & 0x0400) display.print("."); else display.print(" ");
  if (srHall & 0x0100) display.print("O"); else display.print(" ");
  display.print("   ");
  if (srHall & 0x8000) display.print("O"); else display.print(" ");
  if (srHall & 0x4000) display.print("."); else display.print(" ");
  if (srHall & 0x1000) display.print("O"); else display.print(" ");
  display.display(2); //Invia il buffer da visualizzare al display
}
//--------------------------------------------------
//----------------------------------------------------------
void leggiCassetti(void)
{
  for (byte i=0; i<5; i++) posto[i]=0;
  digitalWrite(HALL_LD, 0); digitalWrite(HALL_LD, 1);  //Latch
  digitalWrite(HALL_CLK, 1); digitalWrite(HALL_CLK, 0);  //Clock
  srHall = 0;
  digitalWrite(HALL_LD, 0); digitalWrite(HALL_LD, 1);  //Latch
  for (byte i=0; i<16; i++)
  { srHall = srHall<<1;
    srHall = srHall + digitalRead(HALL_SIN);
    digitalWrite(HALL_CLK, 1); digitalWrite(HALL_CLK, 0);  //Clock
  }
  Serial.print("Shift Register sensori Hall... ");   Serial.println(srHall, BIN); 
}
//----------------------------------------------------------
