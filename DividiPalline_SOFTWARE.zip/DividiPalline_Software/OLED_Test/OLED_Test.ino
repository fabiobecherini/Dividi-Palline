#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);
//#if (SSD1306_LCDHEIGHT != 64)
//#error("Height incorrect, please fix Adafruit_SSD1306.h!");
//#endif

byte prova=0;
void setup()   {    
          
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //Impostare l'indirizzo i2c annotato in precedenza
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(3);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("12"); //Stringa da visualizzare
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("34"); //Stringa da visualizzare
  display.setCursor(68,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("56"); //Stringa da visualizzare
  display.setCursor(102,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("69"); //Stringa da visualizzare
//  display.display(); //Invia il buffer da visualizzare al display

  display.setTextSize(5);  //Imposta la grandezza del testo
  display.setCursor(50,22); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("A"); //Stringa da visualizzare
display.display(); //Invia il buffer da visualizzare al display

}
void loop()
{
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(2);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("12"); //Stringa da visualizzare
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("34"); //Stringa da visualizzare
  display.setCursor(68,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("56"); //Stringa da visualizzare
  display.setCursor(102,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("69"); //Stringa da visualizzare
//  display.display(); //Invia il buffer da visualizzare al display
  display.setTextSize(5);  //Imposta la grandezza del testo
  display.setCursor(50,22); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println(prova%10); //Stringa da visualizzare
  display.display(); //Invia il buffer da visualizzare al display
  prova++;
  delay(100);
 
}
