// Test MOTORE passo-passo UNIPOLARE    10/2020

byte motA=2, motB=3, motC=4, motD=5;
byte nFase=0;
byte LEDR=13;
const byte numFasi=4;
const byte fase[]={0b1000, 0b0100, 0b0010, 0b0001};
//byte fase[]={0b1000, 0b110, 0b0100, 0b0110, 0b0010, 0b0011, 0b0001, 0b1001};
void setup()
{
  pinMode(motA, OUTPUT);
  pinMode(motB, OUTPUT);
  pinMode(motC, OUTPUT);
  pinMode(motD, OUTPUT);
  pinMode(LEDR, OUTPUT);
  nFase=0; 
  StepMotorOut(1,0,1000);
}

void loop()
{
  //StepMotorOut(1,1,2);


  StepMotorOut(1000,0,2);
  delay(1000);
  StepMotorOut(2000,1,2);
  delay(200);

}
void StepMotorOut(int nPassi, boolean direzione, int mSritardo)
{
  for (int passo=1; passo<=nPassi; passo++)
  { if (direzione==0)
    { if (nFase<(numFasi-1)) nFase++; else nFase=0;
    }
    else
    { if (nFase>0) nFase--; else nFase=numFasi-1;
    }
    digitalWrite(motA, fase[nFase]&1);
    digitalWrite(motB, fase[nFase]&2);
    digitalWrite(motC, fase[nFase]&4);
    digitalWrite(motD, fase[nFase]&8);
    delay(mSritardo);
digitalWrite(LEDR, !digitalRead(LEDR));
    
  }
}

