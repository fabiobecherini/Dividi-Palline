#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);

#include <OneWire.h>
#include <LiquidCrystal.h>
 
#define BUTTON A0
int DS18B20_Pin = 2;
 
OneWire ds(DS18B20_Pin);
 
//-------------------------------------------------------------------------
void setup(void)
{
  Serial.begin(9600);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //Impostare l'indirizzo i2c
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(2);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.display(4); //Invia il buffer da visualizzare al display
}
//-------------------------------------------------------------------------
void loop(void)
{
  //float temperature = 80;
  float temperature = getTemp();
  Serial.println(temperature);
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(temperature); //Stringa da visualizzare
  display.display(2); //Invia il buffer da visualizzare al display
  delay(500); //just here to slow down the output so it is easier to read
}
//-------------------------------------------------------------------------
float getTemp()
{
  //returns the temperature from one DS18B20 in DEG Celsius
 
  byte data[12];
  byte addr[8];
 
  if ( !ds.search(addr)) {
      //no more sensors on chain, reset search
      ds.reset_search();
      return -1000;
  }
 
  if ( OneWire::crc8( addr, 7) != addr[7]) {
      Serial.println("CRC is not valid!");
      return -1000;
  }
 
  if ( addr[0] != 0x10 && addr[0] != 0x28) {
      Serial.print("Device is not recognized");
      return -1000;
  }
 
  ds.reset();
  ds.select(addr);
  ds.write(0x44,1); // start conversion, with parasite power on at the end
 
  byte present = ds.reset();
  ds.select(addr);    
  ds.write(0xBE); // Read Scratchpad
 
  for (int i = 0; i < 9; i++) { // we need 9 bytes
    data[i] = ds.read();
  }
 
  ds.reset_search();
 
  byte MSB = data[1];
  byte LSB = data[0];
 
  float tempRead = ((MSB << 8) | LSB); //using two's compliment
  float TemperatureSum = tempRead / 16;
 
  return TemperatureSum;
}
//-------------------------------------------------------------------------

/*
//-------------------------------------------------------------------------
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);
byte prova=0;
//-------------------------------------------------------------------------
void setup()
{    
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //Impostare l'indirizzo i2c annotato in precedenza
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(2);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.display(4); //Invia il buffer da visualizzare al display
}
//-------------------------------------------------------------------------
void loop()
{
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+1); //Stringa da visualizzare
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+2); //Stringa da visualizzare
  display.setCursor(68,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+3); //Stringa da visualizzare
  display.setCursor(102,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  if (prova<10) display.print("0");
  display.print(prova); //Stringa da visualizzare
  display.display(2); //Invia il buffer da visualizzare al display
  prova++;
  if (prova>96) 
  { prova=1;
  }  
}
//-------------------------------------------------------------------------
*/
