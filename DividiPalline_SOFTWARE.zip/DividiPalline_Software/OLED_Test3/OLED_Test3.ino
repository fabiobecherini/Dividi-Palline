#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include "My_OLED_SSD1306.h"
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);
//#if (SSD1306_LCDHEIGHT != 64)
//#error("Height incorrect, please fix Adafruit_SSD1306.h!");
//#endif

byte prova=0;
void setup()   {    
          
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  //Impostare l'indirizzo i2c annotato in precedenza
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setTextSize(2);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
  display.display(4); //Invia il buffer da visualizzare al display
/*
  display.setCursor(0,8); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("12"); //Stringa da visualizzare
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("34"); //Stringa da visualizzare
  display.setCursor(68,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("56"); //Stringa da visualizzare
  display.setCursor(102,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.println("69"); //Stringa da visualizzare
  display.display(); //Invia il buffer da visualizzare al display
*/
}
void loop()
{
/*
  display.setTextSize(2);  //Imposta la grandezza del testo
  display.setTextColor(WHITE); //Imposta il colore del testo (Solo bianco)
*/
  display.clearDisplay();  //Pulisce il buffer da inviare al display
  display.setCursor(0,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+1); //Stringa da visualizzare
  display.setCursor(34,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+2); //Stringa da visualizzare
  display.setCursor(68,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  display.print(prova+3); //Stringa da visualizzare
  display.setCursor(102,0); //Imposta la posizione del cursore (Larghezza,Altezza)
  if (prova<10) display.print("0");
  display.print(prova); //Stringa da visualizzare
  display.display(2); //Invia il buffer da visualizzare al display
  prova++;
  if (prova>96) 
  { prova=1;
//    display.clearDisplay();  //Pulisce il buffer da inviare al display
  }  
  //delay(100);
 
}
